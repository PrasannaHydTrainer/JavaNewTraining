package com.java.dxc;

public enum Gender {

	MALE, FEMALE
}
