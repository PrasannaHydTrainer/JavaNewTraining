package com.java.day1;

class Data {
	public void anusha() {
		System.out.println("Hi I am Anusha...");
	}
	
	void jenil() {
		System.out.println("Hi I am Jenil...");
	}
	
	private void divya() {
		System.out.println("Hi i am Divya...");
	}
}

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.anusha();
		obj.jenil();
	}
}
