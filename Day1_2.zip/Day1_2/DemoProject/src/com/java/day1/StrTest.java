package com.java.day1;

public class StrTest {

	public static void main(String[] args) {
		String s1="Prathyusha", s2="Jitendra", s3="Jenil", s4="Prathyusha";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
