package com.java.day1;

public class Quiz4 {

	public static void main(String[] args) {
		char ch='A';
		int x=ch;
		System.out.println(x);
	}
}
