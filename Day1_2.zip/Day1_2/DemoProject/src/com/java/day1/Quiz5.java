package com.java.day1;

public class Quiz5 {

	boolean flag;
	public static void main(String[] args) {
		Quiz5 obj = new Quiz5();
		System.out.println(obj.flag);
	}
}
