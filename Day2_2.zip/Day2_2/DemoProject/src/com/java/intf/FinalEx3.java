package com.java.intf;

final class Admin {
	
}

//class Demo extends Admin {
//	
//}
public class FinalEx3 {

}
