package com.java.day2;

public class Test {

	int a,b;
//	a=5;
//	b=7;
	
	public static void main(String[] args) {
		
	}
}
