package com.java.day2;

public class Student {

	int sno;
	String name;
	String city;
	double cgp;
	
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", name=" + name + ", city=" + city + ", cgp=" + cgp + "]";
	}
	
	
	
}
