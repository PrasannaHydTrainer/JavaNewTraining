package com.java.cons;

public class ConStudent {

	public static void main(String[] args) {
		Student s1 = new Student();
		System.out.println(s1);
		Student s2 = new Student(3, "Jyothi", 9.3, "Hyderabad");
		System.out.println(s2);
	}
}
