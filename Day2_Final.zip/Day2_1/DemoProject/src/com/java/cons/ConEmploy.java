package com.java.cons;

public class ConEmploy {

	public static void main(String[] args) {
		Employ emp1 = new Employ();
		System.out.println(emp1);
		
		Employ emp2 = new Employ(10, "Jyothi", 93244);
		System.out.println(emp2);
	}
}
