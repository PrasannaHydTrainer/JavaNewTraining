package com.java.abs;

public class Jeevan extends Student {

	public Jeevan(int sno, String name, double cgp, String city) {
		super(sno, name, cgp, city);
		// TODO Auto-generated constructor stub
	}

}
