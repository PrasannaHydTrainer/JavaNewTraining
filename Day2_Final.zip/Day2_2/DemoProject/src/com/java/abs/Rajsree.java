package com.java.abs;

public class Rajsree extends Student {

	public Rajsree(int sno, String name, double cgp, String city) {
		super(sno, name, cgp, city);
		// TODO Auto-generated constructor stub
	}

}
