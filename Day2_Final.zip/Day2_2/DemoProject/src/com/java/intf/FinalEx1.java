package com.java.intf;

public class FinalEx1 {

	public static void main(String[] args) {
		final String company = "Dxc";
		System.out.println(company);
		//company = "Dxc limited";
	}
}
