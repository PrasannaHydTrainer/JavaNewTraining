package com.java.intf;

class First {
	final void admin() {
		System.out.println("Its Admin method not to be overrided...");
	}
}

class Second extends First {
//	void admin() {
//		
//	}
}
public class FinalEx2 {

}
