package com.java.cons;

public class Quiz2 {

	public static void main(String[] args) {
		int[] a = new int[]{12,4,6,33,23};
		for(int i : a) {
		System.out.println(a);
		}
	}
}
