package com.java.cons;

public class StTest {

	static {
		System.out.println("Static Block...");
	}
	
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
