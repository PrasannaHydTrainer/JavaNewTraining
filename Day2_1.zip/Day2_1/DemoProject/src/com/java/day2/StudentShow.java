package com.java.day2;

public class StudentShow {

	public static void main(String[] args) {
		Student s1 = new Student();
		s1.sno=1;
		s1.name="Jagan Mohan";
		s1.cgp=8.4;
		s1.city="Hyderabad";
		
		System.out.println(s1);
	}
}
