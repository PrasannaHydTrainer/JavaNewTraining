package com.java.day2;

public enum LeaveStatus {

	ACCEPTED, REJECTED, PENDING
}
