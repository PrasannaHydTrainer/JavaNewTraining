package com.java.day2;

public class Emp {

	int empno;
	String name;
	double basic;
	
	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", name=" + name + ", basic=" + basic + "]";
	}
	
	
}
