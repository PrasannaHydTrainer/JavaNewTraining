package com.dxc.lms;

public enum LeaveType {
	EL
}
