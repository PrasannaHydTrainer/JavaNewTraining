package com.dxc.lms;

public enum LeaveStatus {

	PENDING, APPROVED, DENIED
}
