package com.java.ex;

public class NumberZeroException extends Exception {

	public NumberZeroException(String error) {
		super(error);
	}
}
